//En los ficheros .h incluiremos #defines, struct y prototipos (cabeceras) de funciones

//cabecera de la funcion esPar
int esPar(int numero);
