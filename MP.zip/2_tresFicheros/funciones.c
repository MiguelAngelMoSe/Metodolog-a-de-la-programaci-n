#include "funciones.h" //nuestros .h van con comillas dobles

int esPar(int numero)
{
   if(numero%2==0)
     return 1;
   else
     return 0;      
}
