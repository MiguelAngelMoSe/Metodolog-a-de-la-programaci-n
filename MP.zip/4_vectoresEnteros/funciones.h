#define MAX_VECTOR 15
void rellenarVector(int Vector[], int nEle);
void imprimirVector(int Vector[], int nEle);
float calcularMedia(int Vector[], int nEle);
